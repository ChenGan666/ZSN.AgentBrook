---
name: hello
description: 简单问候的示例技能，演示基于 SKILL.md 与提示生成严格 JSON 计划，并受控执行。
allowed-tools: []
---

# Hello Skill

## Instructions
- 仅输出严格 JSON，不要多余文本。
- 优先使用 [tools/hello.cs]。
- 仅在需要时执行；否则返回 `plan` 或 `discover`。

## 规划提示（用于 LLM 生成执行计划）
你是一个技能规划助手。基于以下约束生成严格的 JSON 指令（仅 JSON、不要多余文本）：
- 优先使用 tools 目录下的脚本；
- 仅在需要时选择执行；
- JSON 结构示例：

```json
{
  "mode": "execute",
  "run": {
    "relativePath": "tools/hello.cs",
    "args": ["-Name", "World"],
    "env": {},
    "workingDir": ""
  }
}