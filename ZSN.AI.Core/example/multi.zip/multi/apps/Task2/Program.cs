using System;
using System.IO;

namespace Multi.Tasks.Task2;

class Program
{
    static void Main(string[] args)
    {
        // 从标准输入读取 Task1 的输出
        string prev = Console.In.ReadToEnd() ?? string.Empty;
        var result = $"Task2Result:Prev=[{prev}]";
        Console.Write(result);
    }
}
