using System;

namespace Multi.Tasks.Task1;

class Program
{
    static void Main(string[] args)
    {
        // 无输入，直接产出 Task1 结果
        var result = $"Task1Result:{DateTime.Now:yyyyMMddHHmmss}";
        Console.Write(result);
    }
}
