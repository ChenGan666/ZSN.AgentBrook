---
name: multi
description: 多步骤计划示例，任务1→任务2→任务3 串联执行并在工作目录间用文件传递结果。
allowed-tools: ["Task1.ps1","Task2.ps1","Task3.ps1"]
---

# Multi-step Skill

## Instructions
- 仅输出严格 JSON，不要多余文本。
- 输出为多步骤：`steps` 数组，每步 `run.relativePath` 指向 `tools/TaskX.ps1`。
- 各步在执行时的工作目录由系统设定为任务目录，因此脚本可通过 `step1.txt/step2.txt/step3.txt` 传递结果。

## 规划提示
请生成严格 JSON：

```json
{
  "mode": "execute",
  "steps": [
    { "run": { "relativePath": "tools/Task1.ps1", "args": [], "env": {}, "workingDir": "" } },
    { "run": { "relativePath": "tools/Task2.ps1", "args": [], "env": {}, "workingDir": "" } },
    { "run": { "relativePath": "tools/Task3.ps1", "args": [], "env": {}, "workingDir": "" } }
  ]
}
```

注意：不要额外文本。
