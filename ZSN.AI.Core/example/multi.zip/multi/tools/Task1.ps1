param()
$ErrorActionPreference = 'Stop'

# 定位可执行文件（先尝试已构建的 exe，再尝试 dll 用 dotnet 运行）
$base = Split-Path -Parent $PSScriptRoot
$app = Join-Path $PSScriptRoot "..\apps\Task1\bin\Release\net8.0\Task1.exe"
$dll = Join-Path $PSScriptRoot "..\apps\Task1\bin\Release\net8.0\Task1.dll"

if (Test-Path $app) {
    $output = & $app
}
elseif (Test-Path $dll) {
    $output = & dotnet $dll
}
else {
    throw "Task1 未构建，请先在 example/multi/apps/Task1 下执行: dotnet build -c Release"
}

# 写入到当前工作目录(由执行器设置)的文件，供后续步骤读取
Set-Content -Path (Join-Path (Get-Location) "step1.txt") -Value $output -Encoding UTF8

# 也输出到 stdout 以便观察
Write-Output $output
