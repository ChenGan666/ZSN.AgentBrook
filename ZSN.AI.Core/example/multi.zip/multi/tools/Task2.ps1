param()
$ErrorActionPreference = 'Stop'

# 读取上一步的输出
$prevPath = Join-Path (Get-Location) "step1.txt"
if (!(Test-Path $prevPath)) { throw "未找到 step1.txt，请先执行 Task1" }
$prev = Get-Content -Raw -Path $prevPath -Encoding UTF8

# 定位可执行文件
$app = Join-Path $PSScriptRoot "..\apps\Task2\bin\Release\net8.0\Task2.exe"
$dll = Join-Path $PSScriptRoot "..\apps\Task2\bin\Release\net8.0\Task2.dll"

if (Test-Path $app) {
    $output = $prev | & $app
}
elseif (Test-Path $dll) {
    $output = $prev | & dotnet $dll
}
else {
    throw "Task2 未构建，请先在 example/multi/apps/Task2 下执行: dotnet build -c Release"
}

Set-Content -Path (Join-Path (Get-Location) "step2.txt") -Value $output -Encoding UTF8
Write-Output $output
