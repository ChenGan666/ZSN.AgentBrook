param()
$ErrorActionPreference = 'Stop'

# 读取上一步的输出
$prevPath = Join-Path (Get-Location) "step2.txt"
if (!(Test-Path $prevPath)) { throw "未找到 step2.txt，请先执行 Task2" }
$prev = Get-Content -Raw -Path $prevPath -Encoding UTF8

# 定位可执行文件
$app = Join-Path $PSScriptRoot "..\apps\Task3\bin\Release\net8.0\Task3.exe"
$dll = Join-Path $PSScriptRoot "..\apps\Task3\bin\Release\net8.0\Task3.dll"

if (Test-Path $app) {
    $output = $prev | & $app
}
elseif (Test-Path $dll) {
    $output = $prev | & dotnet $dll
}
else {
    throw "Task3 未构建，请先在 example/multi/apps/Task3 下执行: dotnet build -c Release"
}

Set-Content -Path (Join-Path (Get-Location) "step3.txt") -Value $output -Encoding UTF8
Write-Output $output
